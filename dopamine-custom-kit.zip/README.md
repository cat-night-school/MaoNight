# 定制 Dopamine 越狱 IPA（猫夜·越狱）—— 云端自动编译

克隆官方 Dopamine 3.0.12 源码 → 换成你的图标 / 内部背景 / 重启画面图 → GitHub macOS 机器编译 → 输出可安装的 `Dopamine.ipa`。

## 为什么必须云端编译

Dopamine 是 Objective-C 工程，IPA 里的 arm64 二进制只能用 Xcode 编译。Windows 上没有 Xcode，所以用 GitHub Actions 的免费 macOS 机器编译，产物是真 IPA（不是资源包）。

## 使用步骤

1. GitHub 新建仓库（Public 最省事）；
2. 上传本文件夹全部内容（含 `.github`）；
3. Actions →「Build Maonight Dopamine IPA」→ Run workflow；
4. 约 15~25 分钟，运行页底部 Artifacts 下载 `Maonight-Dopamine-IPA`；
5. 解压出 `Dopamine.ipa`，TrollStore / 已越狱环境安装（与官方同 bundle id，会覆盖原 Dopamine，**装前备份官方 IPA**）。

## 可替换的东西

| 文件 | 作用 |
|---|---|
| `assets/icon.png` | 应用图标（1024×1024，**不要透明**） |
| `assets/background.jpg` | App 内部背景（5 套主题背景都会替换） |
| `assets/respring.png` | 重启 / 重启用户空间时显示的那张图（会转成 DopamineLogo.pdf） |

换图后重新 push 就会重新编译。

## 说明

- 只替换资源，不改逻辑，编译稳定；
- 重启画面的图是 `DopamineLogo.imageset/DopamineLogo.pdf`，官方原本就有，这里直接替换成你的图；
- Dopamine 为开源项目（见上游 LICENSE.md），本包只做资源替换与打包，请遵守其许可证。
