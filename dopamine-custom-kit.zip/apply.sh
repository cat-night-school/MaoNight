#!/usr/bin/env bash
# 把猫夜定制资源打进 Dopamine 源码（纯资源替换，编译期生效，不会闪退）
set -e
DOPA="$1"
[ -z "$DOPA" ] && { echo "usage: apply.sh <dopamine-repo>"; exit 1; }
KIT="$(cd "$(dirname "$0")" && pwd)"
APP="$DOPA/Application/Dopamine"

echo "==> app icons"
cd "$APP/Assets.xcassets/AppIcon.appiconset"
while read -r name size; do
  [ -z "$name" ] && continue
  sips -s format png -z "$size" "$size" "$KIT/assets/icon.png" --out "$name" >/dev/null
done <<'EOF'
Icon-38@2x.png 76
Icon-38@3x.png 114
Icon-60@3x.png 180
Icon-64@2x.png 128
Icon-64@3x.png 192
Icon-68@2x.png 136
Icon-76@2x.png 152
Icon-83.5@2x.png 167
Icon-Notification@2x.png 40
Icon-Notification@3x.png 60
Icon-Small-40@2x.png 80
Icon-Small-40@3x.png 120
Icon-Small-40@3x 1.png 120
Icon-Small@2x.png 58
Icon-Small@3x.png 87
EOF

echo "==> header wordmark (顶部标题：猫夜)"
cd "$APP/Assets.xcassets/Dopamine.imageset"
sips -s format png -z 40 203 "$KIT/assets/wordmark.png" --out Dopamine.png >/dev/null
sips -s format png -z 80 405 "$KIT/assets/wordmark.png" --out Dopamine@2x.png >/dev/null
sips -s format png -z 160 810 "$KIT/assets/wordmark.png" --out Dopamine@3x.png >/dev/null

echo "==> app background"
cd "$APP/Assets.xcassets/Background"
for f in Background_Green/green.jpg Background_Blue/blue.jpg Background_Purple/purple.jpg Background_Red/red.jpg Background_ElleKit/ellekit.jpg; do
  sips -s format jpeg "$KIT/assets/background.jpg" --out "$f" >/dev/null
done

echo "==> respring logo"
cd "$APP/Assets.xcassets/DopamineLogo.imageset"
sips -s format pdf -z 600 600 "$KIT/assets/respring.png" --out DopamineLogo.pdf >/dev/null

echo "==> strings"
cp "$KIT/strings/zh-Hans.strings" "$APP/zh-Hans.lproj/Localizable.strings"
for f in "$APP"/*.lproj/Localizable.strings; do
  case "$f" in *zh-Hans*|*zh-Hant*) continue;; esac
  sed -i '' 's/Dopamine/Maonight/g' "$f" 2>/dev/null || sed -i 's/Dopamine/Maonight/g' "$f"
done

echo "==> credits"
cp "$KIT/credits/Credits.plist" "$APP/UI/Settings/Credits.plist"

echo "==> display name"
plutil -replace CFBundleDisplayName -string "猫夜·越狱" "$APP/Info.plist" 2>/dev/null || true
plutil -replace CFBundleName -string "Maonight" "$APP/Info.plist" 2>/dev/null || true

echo "==> done"
