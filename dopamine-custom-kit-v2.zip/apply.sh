#!/usr/bin/env bash
# 猫夜定制：纯源码资源替换（编译期生效）
# 可用环境变量：TITLE / AUTHOR / BG / ICON
set -e
DOPA="$1"
[ -z "$DOPA" ] && { echo "usage: apply.sh <dopamine-repo>"; exit 1; }
KIT="$(cd "$(dirname "$0")" && pwd)"
APP="$DOPA/Application/Dopamine"
ASSETS="$APP/Assets.xcassets"

TITLE="${TITLE:-猫夜}"
AUTHOR="${AUTHOR:-王关喆}"
BG="${BG:-zhbai}"
ICON="${ICON:-cat}"

ICON_SRC="$KIT/assets/icon.png"
[ -f "$KIT/assets/icon-$ICON.png" ] && ICON_SRC="$KIT/assets/icon-$ICON.png"

BG_SRC="$KIT/assets/background.jpg"
[ -f "$KIT/assets/background-$BG.jpg" ] && BG_SRC="$KIT/assets/background-$BG.jpg"

echo "==> 参数：title=$TITLE author=$AUTHOR bg=$BG icon=$ICON"
echo "==> 背景文件：$BG_SRC"

echo "==> app icons"
cd "$ASSETS/AppIcon.appiconset"
while read -r name size; do
  [ -z "$name" ] && continue
  sips -s format png -z "$size" "$size" "$ICON_SRC" --out "$name" >/dev/null
done <<'EOF'
Icon-38@2x.png 76
Icon-38@3x.png 114
Icon-60@3x.png 180
Icon-64@2x.png 128
Icon-64@3x.png 192
Icon-68@2x.png 136
Icon-76@2x.png 152
Icon-83.5@2x.png 167
Icon-Notification@2x.png 40
Icon-Notification@3x.png 60
Icon-Small-40@2x.png 80
Icon-Small-40@3x.png 120
Icon-Small@2x.png 58
Icon-Small@3x.png 87
EOF

echo "==> backgrounds"
n=0
for d in "$ASSETS"/Background*imageset; do
  [ -d "$d" ] || continue
  jpg=$(ls "$d"/*.jpg 2>/dev/null | head -1)
  [ -z "$jpg" ] && continue
  sips -s format jpeg "$BG_SRC" --out "$jpg" >/dev/null
  n=$((n+1))
done
echo "    替换背景 $n 张"

echo "==> respring logo"
logo=$(find "$ASSETS" -name 'DopamineLogo.pdf' | head -1)
if [ -n "$logo" ] && [ -f "$KIT/assets/respring.png" ]; then
  sips -s format pdf -z 600 600 "$KIT/assets/respring.png" --out "$logo" >/dev/null
fi

echo "==> 顶部标题"
grep -rl '@"Dopamine"' "$APP" 2>/dev/null | while read -r f; do
  sed -i '' "s/@\"Dopamine\"/@\"$TITLE\"/g" "$f" 2>/dev/null || sed -i "s/@\"Dopamine\"/@\"$TITLE\"/g" "$f"
done

echo "==> strings"
if [ -f "$APP/zh-Hans.lproj/Localizable.strings" ]; then
  cp "$KIT/strings/zh-Hans.strings" "$APP/zh-Hans.lproj/Localizable.strings"
  sed -i '' "s/王关喆/$AUTHOR/g" "$APP/zh-Hans.lproj/Localizable.strings" 2>/dev/null || \
  sed -i "s/王关喆/$AUTHOR/g" "$APP/zh-Hans.lproj/Localizable.strings"
fi
for f in "$APP"/*.lproj/Localizable.strings; do
  [ -f "$f" ] || continue
  case "$f" in *zh-Hans*) continue;; esac
  sed -i '' "s/Dopamine/$TITLE/g" "$f" 2>/dev/null || sed -i "s/Dopamine/$TITLE/g" "$f"
done

echo "==> credits"
cred=$(find "$APP" -name 'Credits.plist' | head -1)
if [ -n "$cred" ]; then
  cp "$KIT/credits/Credits.plist" "$cred"
  sed -i '' "s/王关喆/$AUTHOR/g" "$cred" 2>/dev/null || sed -i "s/王关喆/$AUTHOR/g" "$cred"
fi

echo "==> display name"
plutil -replace CFBundleDisplayName -string "$TITLE" "$APP/Info.plist" 2>/dev/null || true
plutil -replace CFBundleName -string "Maonight" "$APP/Info.plist" 2>/dev/null || true

echo "==> done"
